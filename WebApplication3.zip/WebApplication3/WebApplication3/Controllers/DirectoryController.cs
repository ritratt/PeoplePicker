﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    public class DirectoryController : Controller
    {
        private DirectoryEntities db = new DirectoryEntities();

        // GET: Directory
        public ActionResult Index()
        {
            return View();
        }

        // GET: Directory/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PeopleFullProfileProd peopleFullProfileProd = db.PeopleFullProfileProds.Find(id);
            if (peopleFullProfileProd == null)
            {
                return HttpNotFound();
            }
            return View(peopleFullProfileProd);
        }

        // GET: Directory/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Directory/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,gtgtid,edupersonprimaryaffiliation,gtprimaryemployeeemailaddress,gtpersondirectoryid,edupersonscopedaffiliation,gtdirguid,objectclass,cn,gtprimaryemailaddress,edupersonaffiliation,mail,gtprimarygtaccountusername,gtprimarystudentemailaddress")] PeopleFullProfileProd peopleFullProfileProd)
        {
            if (ModelState.IsValid)
            {
                db.PeopleFullProfileProds.Add(peopleFullProfileProd);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(peopleFullProfileProd);
        }

        // GET: Directory/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PeopleFullProfileProd peopleFullProfileProd = db.PeopleFullProfileProds.Find(id);
            if (peopleFullProfileProd == null)
            {
                return HttpNotFound();
            }
            return View(peopleFullProfileProd);
        }

        // POST: Directory/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,gtgtid,edupersonprimaryaffiliation,gtprimaryemployeeemailaddress,gtpersondirectoryid,edupersonscopedaffiliation,gtdirguid,objectclass,cn,gtprimaryemailaddress,edupersonaffiliation,mail,gtprimarygtaccountusername,gtprimarystudentemailaddress")] PeopleFullProfileProd peopleFullProfileProd)
        {
            if (ModelState.IsValid)
            {
                db.Entry(peopleFullProfileProd).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(peopleFullProfileProd);
        }

        // GET: Directory/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PeopleFullProfileProd peopleFullProfileProd = db.PeopleFullProfileProds.Find(id);
            if (peopleFullProfileProd == null)
            {
                return HttpNotFound();
            }
            return View(peopleFullProfileProd);
        }

        // POST: Directory/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            PeopleFullProfileProd peopleFullProfileProd = db.PeopleFullProfileProds.Find(id);
            db.PeopleFullProfileProds.Remove(peopleFullProfileProd);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        //GET : Directory/Idontcare
        [Route("Directory/Idontcare")]
        public JsonResult Idontcare()
        {
            return Json(db.PeopleFullProfileProds
                .Select(p => p.cn), JsonRequestBehavior.AllowGet);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
