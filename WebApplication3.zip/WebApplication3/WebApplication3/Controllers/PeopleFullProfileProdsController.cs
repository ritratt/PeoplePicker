﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Web.Http.OData.Routing;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    /*
    The WebApiConfig class may require additional changes to add a route for this controller. Merge these statements into the Register method of the WebApiConfig class as applicable. Note that OData URLs are case sensitive.

    using System.Web.Http.OData.Builder;
    using System.Web.Http.OData.Extensions;
    using WebApplication3.Models;
    ODataConventionModelBuilder builder = new ODataConventionModelBuilder();
    builder.EntitySet<PeopleFullProfileProd>("PeopleFullProfileProds");
    config.Routes.MapODataServiceRoute("odata", "odata", builder.GetEdmModel());
    */
    public class PeopleFullProfileProdsController : ODataController
    {
        private DirectoryEntities db = new DirectoryEntities();

        // GET: odata/PeopleFullProfileProds
        [EnableQuery]
        public IQueryable<PeopleFullProfileProd> GetPeopleFullProfileProds()
        {
            //db.Configuration.ProxyCreationEnabled = false;
            var people = db.PeopleFullProfileProds;
            return people;
        }

        // GET: odata/PeopleFullProfileProds(5)
        [EnableQuery]
        public SingleResult<PeopleFullProfileProd> GetPeopleFullProfileProd([FromODataUri] int key)
        {
            return SingleResult.Create(db.PeopleFullProfileProds.Where(peopleFullProfileProd => peopleFullProfileProd.ID == key));
        }

        // PUT: odata/PeopleFullProfileProds(5)
        public IHttpActionResult Put([FromODataUri] int key, Delta<PeopleFullProfileProd> patch)
        {
            Validate(patch.GetEntity());

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            PeopleFullProfileProd peopleFullProfileProd = db.PeopleFullProfileProds.Find(key);
            if (peopleFullProfileProd == null)
            {
                return NotFound();
            }

            patch.Put(peopleFullProfileProd);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PeopleFullProfileProdExists(key))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(peopleFullProfileProd);
        }

        // POST: odata/PeopleFullProfileProds
        public IHttpActionResult Post(PeopleFullProfileProd peopleFullProfileProd)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.PeopleFullProfileProds.Add(peopleFullProfileProd);
            db.SaveChanges();

            return Created(peopleFullProfileProd);
        }

        // PATCH: odata/PeopleFullProfileProds(5)
        [AcceptVerbs("PATCH", "MERGE")]
        public IHttpActionResult Patch([FromODataUri] int key, Delta<PeopleFullProfileProd> patch)
        {
            Validate(patch.GetEntity());

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            PeopleFullProfileProd peopleFullProfileProd = db.PeopleFullProfileProds.Find(key);
            if (peopleFullProfileProd == null)
            {
                return NotFound();
            }

            patch.Patch(peopleFullProfileProd);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PeopleFullProfileProdExists(key))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(peopleFullProfileProd);
        }

        // DELETE: odata/PeopleFullProfileProds(5)
        public IHttpActionResult Delete([FromODataUri] int key)
        {
            PeopleFullProfileProd peopleFullProfileProd = db.PeopleFullProfileProds.Find(key);
            if (peopleFullProfileProd == null)
            {
                return NotFound();
            }

            db.PeopleFullProfileProds.Remove(peopleFullProfileProd);
            db.SaveChanges();

            return StatusCode(HttpStatusCode.NoContent);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool PeopleFullProfileProdExists(int key)
        {
            return db.PeopleFullProfileProds.Count(e => e.ID == key) > 0;
        }
    }
}
